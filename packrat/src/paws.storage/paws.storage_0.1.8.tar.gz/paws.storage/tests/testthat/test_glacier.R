context("glacier")

svc <- paws::glacier()


