context("apigatewaymanagementapi")

svc <- paws::apigatewaymanagementapi()


