context("apigateway")

svc <- paws::apigateway()


