context("globalaccelerator")

svc <- paws::globalaccelerator()


