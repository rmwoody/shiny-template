context("directconnect")

svc <- paws::directconnect()


