library(testthat)
library(paws.common)

test_check("paws.common")
