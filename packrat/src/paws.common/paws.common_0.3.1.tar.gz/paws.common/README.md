# paws.common

paws.common provides functions to work with Amazon Web Services (AWS) APIs, such
as building and sending requests. It is designed to support the Paws packages,
each of which handles a separate AWS API, e.g. the Elastic Compute Cloud (EC2)
API.
