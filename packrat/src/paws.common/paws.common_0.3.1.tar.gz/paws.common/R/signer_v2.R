# TODO: Implement.
v2_sign_request_handler <- function(request) {
  return(request)
}
