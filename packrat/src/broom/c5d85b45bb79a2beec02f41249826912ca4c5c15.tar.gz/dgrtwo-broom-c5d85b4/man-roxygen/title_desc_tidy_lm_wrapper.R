#' @title Tidy a(n) <%= class %> object
#' 
#' @description This method wraps [tidy.lm()].
#'   
#' @inherit tidy.lm return params
#' 
#' @seealso [tidy()], [tidy.lm()]
#' 
#' @md
