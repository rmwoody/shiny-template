#' @param newdata A [data.frame()] or [tibble::tibble()] containing all
#'   the original predictors used to create `x`. Defaults to `NULL`, indicating
#'   that nothing has been passed to `newdata`. If `newdata` is specified,
#'   the `data` argument will be ignored.
#' @md
