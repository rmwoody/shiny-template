#' @param type.residuals Character indicating type of residuals to use. Passed
#'   to the `type` argument of [stats::residuals()] generic. Allowed arguments
#'   vary with model class, so be sure to read the `residuals.my_class`
#'   documentation.
#' @md
