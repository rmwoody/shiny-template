#' @return \item{term}{The name of the regression term.}
