#' @title Tidy/glance a(n) <%= class %> object
#' 
#' @description For models that have only a single component, the [tidy()] and
#'   [glance()] methods are identical. Please see the documentation for both
#'   of those methods.   
#' 
#' @md
