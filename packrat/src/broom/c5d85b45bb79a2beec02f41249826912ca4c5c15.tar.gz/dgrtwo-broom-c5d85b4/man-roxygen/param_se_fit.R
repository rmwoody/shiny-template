#' @param se_fit Logical indicating whether or not a `.se.fit` column should be
#'   added to the augmented output. For some models, this calculation can be
#'   somwhat time-consuming. Defaults to `FALSE`.
#' @md
