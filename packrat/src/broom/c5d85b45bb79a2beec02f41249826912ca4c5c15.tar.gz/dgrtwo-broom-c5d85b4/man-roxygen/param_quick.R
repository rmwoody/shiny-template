#' @param quick Logical indiciating if the only the `term` and `estimate`
#'   columns should be returned. Often useful to avoid time consuming
#'   covariance and standard error calculations. Defaults to `FALSE`.
#' @md
