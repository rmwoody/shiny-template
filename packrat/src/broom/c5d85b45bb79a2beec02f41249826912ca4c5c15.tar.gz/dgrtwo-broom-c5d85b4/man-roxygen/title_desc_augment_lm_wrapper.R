#' @title Augment a(n) <%= class %> object
#' 
#' @description This augment method wraps [augment.lm()].
#' 
#' @inherit augment.lm params return
#' 
#' @seealso [augment()], [augment.lm()]
#' 
#' @md
