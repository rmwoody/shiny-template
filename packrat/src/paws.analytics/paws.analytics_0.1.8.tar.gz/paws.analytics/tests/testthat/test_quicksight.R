context("quicksight")

svc <- paws::quicksight()


