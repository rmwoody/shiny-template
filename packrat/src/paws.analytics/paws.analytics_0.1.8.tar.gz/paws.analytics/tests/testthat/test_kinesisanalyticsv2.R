context("kinesisanalyticsv2")

svc <- paws::kinesisanalyticsv2()


