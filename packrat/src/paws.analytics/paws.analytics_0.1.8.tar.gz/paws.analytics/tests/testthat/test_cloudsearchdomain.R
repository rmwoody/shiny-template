context("cloudsearchdomain")

svc <- paws::cloudsearchdomain()


