context("pinpointemail")

svc <- paws::pinpointemail()


