context("pinpointsmsvoice")

svc <- paws::pinpointsmsvoice()


