context("textract")

svc <- paws::textract()


