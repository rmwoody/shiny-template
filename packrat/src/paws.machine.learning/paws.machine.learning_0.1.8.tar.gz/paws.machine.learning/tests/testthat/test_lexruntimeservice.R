context("lexruntimeservice")

svc <- paws::lexruntimeservice()


