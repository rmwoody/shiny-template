context("sagemakerruntime")

svc <- paws::sagemakerruntime()


