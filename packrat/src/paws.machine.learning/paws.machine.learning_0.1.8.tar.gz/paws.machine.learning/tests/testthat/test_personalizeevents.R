context("personalizeevents")

svc <- paws::personalizeevents()


