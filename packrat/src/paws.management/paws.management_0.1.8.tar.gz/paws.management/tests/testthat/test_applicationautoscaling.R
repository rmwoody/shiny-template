context("applicationautoscaling")

svc <- paws::applicationautoscaling()


