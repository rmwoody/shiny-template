context("licensemanager")

svc <- paws::licensemanager()


