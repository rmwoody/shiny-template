
[![Travis-CI Build Status](https://travis-ci.org/JohnCoene/echarts4r.svg?branch=master)](https://travis-ci.org/JohnCoene/echarts4r) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/JohnCoene/echarts4r?branch=master&svg=true)](https://ci.appveyor.com/project/JohnCoene/echarts4r) [![Bitbucket Build Status](https://img.shields.io/bitbucket/pipelines/JohnCoene/echarts4r.svg)](https://bitbucket.org/JohnCoene/echarts4r) [![lifecycle](https://img.shields.io/badge/lifecycle-maturing-blue.svg)](https://www.tidyverse.org/lifecycle/#maturing) [![Binder](http://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/JohnCoene/echarts4r/master) [![version](https://img.shields.io/github/tag/JohnCoene/echarts4r.svg)](https://github.com/JohnCoene/echarts4r/releases) [![GitHub closed issues](https://img.shields.io/github/issues-closed/JohnCoene/echarts4r.svg)](https://github.com/JohnCoene/echarts4r/issues) [![echarts4r](https://cranlogs.r-pkg.org/badges/echarts4r)](https://cranlogs.r-pkg.org/badges/echarts4r)

# echarts4r

![sticker](https://raw.githubusercontent.com/JohnCoene/echarts4r/master/docs/logo.png)

ECharts 4 for R, see the [website](http://echarts4r.john-coene.com) for examples and documentation.
