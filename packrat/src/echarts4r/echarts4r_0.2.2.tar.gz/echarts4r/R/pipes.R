#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

#' @importFrom dplyr group_by
#' @export
dplyr::group_by

#' @importFrom dplyr group_by_
#' @export
dplyr::group_by_