`draft` <-
structure(list(to = "My dog <mydog@gmail.com>", from = "gWidgetsRGtk <gWidgetsRGtk@gmail.com>", 
    subject = "", text = ""), .Names = c("to", "from", "subject", 
"text"))
