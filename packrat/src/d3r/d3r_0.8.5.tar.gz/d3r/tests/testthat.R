library(testthat)
library(d3r)

test_check("d3r")
