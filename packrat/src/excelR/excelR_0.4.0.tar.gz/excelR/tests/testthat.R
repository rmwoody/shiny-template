library(testthat)
library(excelR)

test_check("excelR")
