context("lightsail")

svc <- paws::lightsail()


