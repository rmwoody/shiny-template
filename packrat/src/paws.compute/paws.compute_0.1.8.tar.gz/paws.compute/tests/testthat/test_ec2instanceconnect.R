context("ec2instanceconnect")

svc <- paws::ec2instanceconnect()


