context("marketplacecommerceanalytics")

svc <- paws::marketplacecommerceanalytics()


