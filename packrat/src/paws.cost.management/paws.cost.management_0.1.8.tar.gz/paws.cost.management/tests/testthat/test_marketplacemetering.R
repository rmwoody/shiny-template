context("marketplacemetering")

svc <- paws::marketplacemetering()


