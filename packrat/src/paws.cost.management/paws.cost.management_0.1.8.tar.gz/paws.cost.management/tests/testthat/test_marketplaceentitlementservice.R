context("marketplaceentitlementservice")

svc <- paws::marketplaceentitlementservice()


