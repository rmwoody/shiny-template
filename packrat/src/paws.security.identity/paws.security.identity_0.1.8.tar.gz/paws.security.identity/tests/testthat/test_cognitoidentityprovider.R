context("cognitoidentityprovider")

svc <- paws::cognitoidentityprovider()


