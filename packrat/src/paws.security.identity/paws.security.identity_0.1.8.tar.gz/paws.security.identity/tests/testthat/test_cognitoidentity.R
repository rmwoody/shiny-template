context("cognitoidentity")

svc <- paws::cognitoidentity()


