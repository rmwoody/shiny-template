context("sts")

svc <- paws::sts()


